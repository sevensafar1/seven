 <!-- MOBILE MENU -->

 <style>
    .main-menu {
    float: left;
    width: 80%;
}
.contcct{
   
    /* margin-top: 18px;
    font-style: bold; */
    font-weight: bold;
    color: black;

}
 </style>

 <section>

        <div class="ed-mob-menu">

            <div class="ed-mob-menu-con">

                <div class="ed-mm-left">

                    <div class="wed-logo">

                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('public/front/image/logo.png')); ?>" alt="" />

                        </a>

                    </div>

                </div>

                <div class="ed-mm-right">

                    <div class="ed-mm-menu">

                        <a href="#!" class="ed-micon"><i class="fa fa-bars"></i></a>

                        <div class="ed-mm-inn">

                            <a href="#!" class="ed-mi-close"><i class="fa fa-times"></i></a>

                            <ul>

                                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>

                                <li><a href="<?php echo e(route('about')); ?>">About</a></li>

                            </ul>

                            <?php



                             $package=package(); 

                             $copackage=corporatepackage();

                             ?> 

                            <h4>Tour Packages</h4>

                            <ul>

                                <?php if($package): ?>

                                    <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                   

                                    <li><a href="<?php echo e(route('package',$pack->slug)); ?>"><?php echo e($pack->package_name); ?></a></li>

                                  

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>

                            </ul>

                            <ul>

                               

                                <li><a href="<?php echo e(route('hotels')); ?>">Hotels</a></li>

                                <li><a href="<?php echo e(route('resort')); ?>">Resorts</a></li>

                                <li><a href="<?php echo e(route('contact')); ?>">Contact us</a></li>
                                <li class="contcct"><a href="tel:+9818054830">9818054830</a></li>
                                <li class="contcct"><a href="tel:+9818055980">9818055980</a></li>

                            </ul>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <!--HEADER SECTION-->

    <section>

        <div class="top-logo" data-spy="affix" data-offset-top="250">

            <div class="container">

                <div class="row">

                    <div class="col-md-12">

                        <div class="wed-logo">

                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('public/front/image/logo.png')); ?>" alt="" />

                            </a>

                        </div>

                        

                        <div class="main-menu">

                            <ul>

                                <li><a href="<?php echo e(route('home')); ?>">Home</a>

                                </li>

                                <li>

                                    <a href="<?php echo e(route('about')); ?>">About</a>

                                </li>

                                <li class="cour-menu">

                                    <a href="#" class="mm-arr">Tour Package</a>

                                    <div class="mm-pos">

                                        <div class="cour-mm m-menu">

                                            <div class="m-menu-inn">

                                                <div class="mm1-com mm1-cour-com mm1-s3">

                                                <ul>

                                                    <?php if($package): ?>

                                                        <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <li><a href="<?php echo e(route('package', $pack->slug)); ?>"><?php echo e($pack->package_name); ?></a></li>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <?php endif; ?>

                                                </ul>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </li>

                                
                                <li><a href="<?php echo e(route('hotels')); ?>">Hotels</a>

                                </li>

                                <li><a href="<?php echo e(route('resort')); ?>">Resorts</a></li>

                                <li><a href="<?php echo e(route('contact')); ?>">Contact us</a></li>
                                <li class="contcct"><a href="tel:+9818054830">9818054830</a></li>
                                <li class="contcct"><a href="tel:+9818055980">9818055980</a></li>

                            </ul>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <!--END HEADER SECTION--><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>