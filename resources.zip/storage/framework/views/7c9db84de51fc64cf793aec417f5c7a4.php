

<?php $__env->startSection('content'); ?>


<section class="gallery-section pb-5 mb-5">
        <div class="container">
            <div class="spe-title">
                <h2>Our <span>gallery</span></h2>
                <div class="title-line">
                    <div class="tl-1"></div>
                    <div class="tl-2"></div>
                    <div class="tl-3"></div>
                </div>
            </div>
            <div class="row">
                <?php if($gallery): ?>
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-12 p-4">
                    <div class="galleryimg">
                        <img src="<?php echo e($gall->image ? asset('images/gallery/' . $gall->image) : asset('images/gallery/'. $gall->image)); ?>" alt="<?php echo e($gall->alt); ?>">
                        <div class="overlay">
                            <div>
                                <h3><?php echo e($gall->title); ?></h3>
                                <p><?php echo e($gall->location); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                

            </div>
            
        </div>
    </section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/front/gallery.blade.php ENDPATH**/ ?>