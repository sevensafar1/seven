

<?php $__env->startSection('content'); ?>

    <!--====== BANNER ==========-->
    <section>
        <div class="rows inner_banner inner_banner_1">
            <div class="container">
                <div class="spe-title tit-inn-pg">
                    <h1> <span>Blog</span> </h1>
                    <div class="title-line">
                        <div class="tl-1"></div>
                        <div class="tl-2"></div>
                        <div class="tl-3"></div>
                    </div>
                    <!-- <p>Book travel packages and enjoy your holidays with distinctive experience</p>
					<ul>
						<li><a href="main.html">Home</a></li>
						<li><i class="fa fa-angle-right" aria-hidden="true"></i> </li>
						<li><a href="#" class="bread-acti">Blogs</a>
						</li>
					</ul> -->
                </div>
            </div>
        </div>
    </section>
    <!--====== ALL POST ==========-->
    <section>
        <div class="rows inn-page-bg com-colo">
            <div class="container inn-page-con-bg tb-space pad-bot-redu-5" id="inner-page-title">
                <!--===== POSTS ======-->
                <div class="rows">
                   
                    <div class="posts">
                    <?php if($blogs): ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                        <img src="<?php echo e(asset('images/Blog/' . $blog->image)); ?>" 
                        alt="<?php echo e(pathinfo($blog->image, PATHINFO_FILENAME)); ?>">
                            <div class="bloglist-text">
                                <h2><?php echo e($blog->title); ?></h2>
                                <!-- <h5>
                                    <span class="post_author">Author: Johnson</span>
                                    <span class="post_date">Date: 12thMay,2016</span>
                                    <span class="post_city">City: Illunois</span></h5> -->
                                    <?php echo Str::words($blog->description, 15, '...'); ?><br>
                                <a href="<?php echo e(route('blog/detail', $blog->slug)); ?>" class="link-btn">Read more</a>
                            </div>
                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                       
                    


                    </div>
                </div>
                <!--===== POST END ======-->
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/front/blog.blade.php ENDPATH**/ ?>