 
<?php $__env->startSection('content'); ?>
    <!-- Your custom content for index page goes here -->
    <div class="container">
        <h1>Welcome to the Admin Dashboard</h1>
        <!-- Other content for the page -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bandhavg/sevensafar.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>