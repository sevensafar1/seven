 


<style>
    .addbtndes
    {
        background-color: #178750 !important;
        border: none !important;
        border-radius: 50% !important;
        padding: 7px 15px !important;  
    }
    .minusbtndes
    {
        background-color: #ee1010 !important;
        border: none !important;
        border-radius: 50% !important;
        padding: 9px 19px !important;
        margin-left: 11px;
    }
    .remove-image
    {
        position: absolute;
        top: -8%;
        left: 68%;
        border-radius: 50% !important;
        padding: 2px 10px !important;
    }
</style>


<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Package</h6>
                <form id="packageUpdateForm" action="<?php echo e(route('package/update')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>  
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Package Title</label>
                    <input type="text" class="form-control" id="name" name="title" value="<?php echo e($package->title); ?>">
                    <span class="text-danger" id="title_error"></span>
                </div>   
                <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Package Name</label>
                        <input type="hidden" class="form-control" name="update_id" value="<?php echo e($package->slug); ?>">
                        <input type="hidden" class="form-control" name="package_id" value="<?php echo e($package->id); ?>">
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($package->name); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="images" class="form-label">Images</label>
                        <input type="file" class="form-control" id="images" name="images[]" multiple>
                    </div>
                    <div id="imagePreviewContainer" class="mt-2 d-flex flex-wrap">
                        <?php
                            $existingImages = \App\Models\PackageImage::where('package_id', $package->id)->get();
                        ?>

                        <?php if($existingImages->count()): ?>
                            <?php $__currentLoopData = $existingImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="image-preview d-flex align-items-center mb-2 position-relative" id="preview-<?php echo e($image->id); ?>">
                                    <img src="<?php echo e(asset('images/packages/' . $image->images)); ?>" alt="Image Preview" class="img-thumbnail" style="width: 100px; height: auto; margin-right: 10px;">
                                    <button type="button" class="btn btn-danger remove-image" data-id="<?php echo e($image->id); ?>">x</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No images uploaded yet.</p>
                        <?php endif; ?>
                    </div>
                    <!-- Arrival Date -->
                    <div class="mb-3">
                        <label for="arrival_date" class="form-label">Arrival Date</label>
                        <input type="date" class="form-control" id="arrival_date" name="arrival_date" value="<?php echo e(old('arrival_date', $package->arrival_date)); ?>" required>
                    </div>

                    <!-- Departure Date -->
                    <div class="mb-3">
                        <label for="departure_date" class="form-label">Departure Date</label>
                        <input type="date" class="form-control" id="departure_date" name="departure_date" value="<?php echo e(old('departure_date', $package->departure_date)); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="amount" class="form-label">Price</label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo e($package->price); ?>" >
                        <span class="text-danger" id="price_error"></span>
                    </div>
                     <!-- Amount -->
                    <div class="mb-3">
                        <label for="amount" class="form-label">Amount</label>
                        <input type="number" step="0.01" class="form-control" id="amount" name="amount" value="<?php echo e($package->amount); ?>" required>
                    </div>

                    <!-- Days -->
                    <div class="mb-3">
                        <label for="days" class="form-label">Days</label>
                        <input type="number" class="form-control" id="days" name="days" value="<?php echo e($package->days); ?>" required>
                    </div>

                    <!-- Nights -->
                    <div class="mb-3">
                        <label for="nights" class="form-label">Nights</label>
                        <input type="number" class="form-control" id="nights" name="nights" value="<?php echo e($package->nights); ?>" required>
                    </div>

                    <!-- Location -->
                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" value="<?php echo e($package->location); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="productDescription" class="form-label">Description</label>
                        <textarea id="productDescription" name="description"><?php echo e($package->description); ?></textarea>
                    </div>
                    <?php $tourData = json_decode($package->about_tour, true); ?>
                    <!-- About Tour (Array) -->
                    <div class="mb-3">
                        <label for="about_tour" class="form-label">About Tour</label><br>
                        <div id="aboutTourContainer">
                            <?php if(isset($tourData) && count($tourData['place']) > 0): ?>
                                <?php $__currentLoopData = $tourData['place']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row mb-3 about-tour-item">
                                        <div class="col">
                                            <input type="text" class="form-control mb-1" name="place[]" value="<?php echo e($place); ?>" placeholder="Place covered">
                                        </div>
                                        <div class="col">
                                            <input type="text" class="form-control mb-1" name="inclusions[]" value="<?php echo e($tourData['inclusions'][$index] ?? ''); ?>" placeholder="Inclusions">
                                        </div>
                                        <div class="col">
                                            <input type="text" class="form-control mb-1" name="exclusions[]" value="<?php echo e($tourData['exclusions'][$index] ?? ''); ?>" placeholder="Exclusions">
                                        </div>
                                        <div class="col d-flex align-items-center">
                                            <input type="text" class="form-control mb-1" name="event_date[]" value="<?php echo e($tourData['event_date'][$index] ?? ''); ?>" placeholder="Event Date">
                                            <?php if($index === 0): ?>
                                                <a href="JavaScript:void(0)" class="btn btn-primary ms-2" id="addMoreTour">+</a>
                                            <?php else: ?>
                                                <a href="JavaScript:void(0)" class="btn btn-danger ms-2 removeTourSection">-</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <!-- Initial Tour Row if no data -->
                                <div class="row mb-3 about-tour-item">
                                    
                                    <div class="col">
                                        <input type="text" class="form-control mb-1" name="place[]" placeholder="Place covered">
                                    </div>
                                    <div class="col">
                                        <input type="text" class="form-control mb-1" name="inclusions[]" placeholder="Inclusions">
                                    </div>
                                    <div class="col">
                                        <input type="text" class="form-control mb-1" name="exclusions[]" placeholder="Exclusions">
                                    </div>
                                    <div class="col d-flex align-items-center">
                                        <input type="text" class="form-control mb-1" name="event_date[]" placeholder="Event Date">
                                        <a href="JavaScript:void(0)" class="btn btn-primary ms-2" id="addMoreTour">+</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php $tourDescription = json_decode($package->tour_description, true); ?>
                    <div class="mb-3">
                        <label for="tour_description" class="form-label">Tour Description</label><br>
                        <div id="tourDescriptionContainer">
                            <?php if(isset($tourDescription) && count($tourDescription['tourtitle']) > 0): ?>
                                <?php $__currentLoopData = $tourDescription['tourtitle']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tour-description-item mb-3">
                                        <input type="text" class="form-control mb-1" name="tourtitle[]" value="<?php echo e($title); ?>" placeholder="Tour Title" required />
                                        <textarea class="form-control mb-3" name="tour_description[]" rows="3" placeholder="Enter tour descriptions, one per line" required><?php echo e($tourDescription['tour_description'][$index] ?? ''); ?></textarea>
                                        
                                        <?php if($index === 0): ?>
                                            <a href="JavaScript:void(0)" class="btn btn-primary ms-2" id="addMoreDescription">+</a>
                                        <?php else: ?>
                                            <a href="JavaScript:void(0)" class="btn btn-danger ms-2 removeDescription">-</a>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="tour-description-item mb-3">
                                    <input type="text" class="form-control mb-1" name="tourtitle[]" placeholder="Tour Title" required />
                                    <textarea class="form-control mb-3" name="tour_description[]" rows="3" placeholder="Enter tour descriptions, one per line" required></textarea>
                                    <a href="JavaScript:void(0)" class="btn btn-primary ms-2" id="addMoreDescription">+</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Package Type -->
                    <div class="mb-3">
                        <label for="package_type" class="form-label">Package Type</label>
                        <select class="form-select" id="package_type" name="package_type">
                            <option value="">----- Select type ------- </option>
                            <?php if($packageType): ?>
                                <?php $__currentLoopData = $packageType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>" <?php echo e($package->package_type == $type->id ? 'selected' : ''); ?>>
                                        <?php echo e($type->package_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <option value="1" <?php echo e($package->package_type == 1 ? 'selected' : ''); ?>>Domestic</option>
                        </select>
                    </div>
                   
                    <button type="submit" class="btn btn-primary" id="submitBtn">Submit
                    <span id="submitBtnSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
            $('#productDescription').summernote({
                height: 200, // Set the height of the editor
                placeholder: 'Enter product description here...'
            });
            $('#addMoreTour').on('click', function () {
                var newSection ='<div class="row mb-3 about-tour-item"><div class="col"><input type="text" class="form-control mb-1" name="place[]" placeholder="Place covered"></div><div class="col"><input type="text" class="form-control mb-1" name="inclusions[]" placeholder="Inclusions"></div><div class="col"><input type="text" class="form-control mb-1" name="exclusions[]" placeholder="Exclusions"></div><div class="col d-flex align-items-center"><input type="text" class="form-control mb-1" name="event_date[]" placeholder="Event Date"><a href="JavaScript:void(0)" class="btn btn-danger ms-2 removeTourSection">-</a></div></div>';

                // Append the new section to the aboutTourContainer
                $('#aboutTourContainer').append(newSection);
            });
            $(document).on('click', '.removeTourSection', function () {
                // Remove the specific about-tour-item that the button is within
                $(this).closest('.about-tour-item').remove();
            });
            $('#addMoreDescription').on('click', function () {
            var newDescription = `
                <div class="tour-description-item mt-3">
                    <input type="text" class="form-control mb-1" name="tourtitle[]" placeholder="Tour Title" required />
                    <textarea class="form-control mb-3" name="tour_description[]" rows="3" placeholder="Enter tour descriptions, one per line" required></textarea>
                    <a href="JavaScript:void(0)" class="btn btn-danger removeDescription">-</a>
                </div>
            `;

            // Append the new description section before the "Add" button (after the last description item)
            $('#tourDescriptionContainer').append(newDescription);
        });
        $(document).on('click', '.removeDescription', function () {
            $(this).closest('.tour-description-item').remove();
        });
        $(document).on('submit', '#packageUpdateForm', function(event) {

            event.preventDefault(); // Prevent default form submission
            $('#loading').css('display', ''); // Show loading indicator
            $('#submitBtn').prop('disabled', true); // Disable the submit button
            $('#submitBtnSpinner').removeClass('d-none'); // Show spinner

            var form = $(this);
            var data = new FormData(form[0]); // Gather form data
            var url = form.attr("action"); // Get form action URL

            $.ajax({
                type: 'POST', // Use POST method
                url: url, // URL for submission
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    $('#loading').css('display', 'none'); // Hide loading indicator
                    toastr.success(response.message); // Show success message
                    window.setTimeout(function() {
                        window.location.href = "<?php echo e(route('package/list')); ?>"; // Redirect after 1 second
                    }, 1000);
                },
                error: function(err) {
                    $('#loading').css('display', 'none'); // Hide loading indicator
                    $('#submitBtn').prop('disabled', false); // Re-enable the submit button
                    $('#submitBtnSpinner').addClass('d-none'); // Hide spinner
                    
                    if (err.status === 422) { // Handle validation errors
                        var error = $.parseJSON(err.responseText);
                        $.each(error.errors, function(key, val) {
                            toastr.error(val[0]); // Show error message
                        });
                    } else {
                        toastr.error('Something went wrong. Please try again.'); // Generic error message
                    }
                }
            });

            return false; // Prevent further event handling
        });
        $('#images').on('change', function(event) {
        const files = event.target.files;
        const previewContainer = $('#imagePreviewContainer');

        // Loop through the selected files
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const reader = new FileReader();

            // Create a preview for each file
            reader.onload = function(e) {
                const imagePreview = `
                    <div class="image-preview d-flex align-items-center mb-2 position-relative" id="preview-new-${i}">
                        <img src="${e.target.result}" alt="Image Preview" class="img-thumbnail" style="width: 100px; height: auto; margin-right: 10px;">
                        <button type="button" class="btn btn-danger remove-image" data-id="new-${i}">x</button>
                    </div>
                `;
                previewContainer.append(imagePreview); // Append the new preview
            };

            reader.readAsDataURL(file);
        }
    });
 
    $(document).on('click', '.remove-image', function() {
        const imageId = $(this).data('id'); // Get the image ID
        console.log('Image ID:', imageId, 'Type:', typeof imageId); // Debugging line
        const imagePreview = $(this).closest('.image-preview'); // Find the parent div

        // Check if imageId is indeed a string
        if (typeof imageId === 'string' && imageId.startsWith('new-')) {
            // For new images (not yet uploaded), just remove from preview
            imagePreview.remove();
        } else {
            // AJAX request to delete the existing image from the database
            $.ajax({
                url: '/delete-image/' + imageId, // Adjust this URL to your route
                type: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        imagePreview.remove(); // Remove the preview from the DOM
                        toastr.success(response.message); // Show success message
                    } else {
                        toastr.error('Failed to delete the image.'); // Show error message
                    }
                },
                error: function() {
                    toastr.error('An error occurred while deleting the image.');
                }
            });
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/admin/package/edit.blade.php ENDPATH**/ ?>