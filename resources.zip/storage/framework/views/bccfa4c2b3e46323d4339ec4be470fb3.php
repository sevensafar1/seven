<?php $__env->startSection('content'); ?>





<section class="gallery-section pb-5 mb-5">

        <div class="container">

            <div class="spe-title">

                <h2>Our <span>gallery</span></h2>

                <div class="title-line">

                    <div class="tl-1"></div>

                    <div class="tl-2"></div>

                    <div class="tl-3"></div>

                </div>

            </div>

            <div class="row">

            <?php $gallery = gallery(); ?>

        <?php if($gallery): ?>
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Decode the JSON string into a PHP array
                    $images = json_decode($gall->image, true);
                ?>

                <div class="col-lg-4 col-md-4 col-sm-12 p-4">
                    <div class="galleryimg">
                        <?php if(!empty($images) && is_array($images) && isset($images[0])): ?>
                            <img src="<?php echo e(asset('public/images/gallery/' . trim($images[0], '"'))); ?>" alt="<?php echo e($gall->alt); ?>">
                        <?php else: ?>
                            <span>No image available</span> <!-- Fallback if no images exist -->
                        <?php endif; ?>
                        <a href="<?php echo e(route('gallery/image',$gall->slug)); ?>">
                        <div class="overlay">
                            <div>
                                <h3><?php echo e($gall->title); ?></h3>
                                <p><?php echo e($gall->location); ?></p>
                            </div>
                        </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

            </div>

            

        </div>

    </section>









<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bandhavg/sevensafar.com/resources/views/front/gallery.blade.php ENDPATH**/ ?>