

<?php $__env->startSection('content'); ?>


    <section>
		<div class="rows inner_banner inner_banner_2">
			<div class="container">
				<div class="spe-title tit-inn-pg">
					<h1><span>Package</span> </h1>
                    <div class="title-line">
						<div class="tl-1"></div>
						<div class="tl-2"></div>
						<div class="tl-3"></div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <section class="package-section pb-5 mb-5 pt-5">
        <div class="container">
            <div class="spe-title">
                <h2><span><?php echo e($packtype->package_name); ?></span></h2>
                <div class="title-line">
                    <div class="tl-1"></div>
                    <div class="tl-2"></div>
                    <div class="tl-3"></div>
                </div>
            </div>
            <div class="row">
                <?php if($package): ?>
                    <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-12 p-4">
                        <div class="packageimg">
                        <?php
                            // Fetch the first image for the current package
                            $image = $data->images()->orderBy('id', 'asc')->first();
                        ?>
                            <img src="<?php echo e($image ? asset('images/packages/' . $image->images) : asset('images/packages/'. $image->images)); ?>" alt="<?php echo e($data->name); ?>">
                            <div class="overlay">
                                <div class="packdetail">
                                    <h3><?php echo e($data->name); ?></h3>
                                    <p>(<?php echo e($data->nights); ?> Nights / <?php echo e($data->days); ?> Days)</p>
                                    <a href="<?php echo e(route('enquiry')); ?>"><button>Enquiry</button></a>
                                    <a href="<?php echo e(route('package.details', $data->slug)); ?>"><button >View Details</button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>

        </div>
    </section>
    

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/front/corporate.blade.php ENDPATH**/ ?>