<?php $__env->startSection('content'); ?>

<section class="gallery-section pb-5 mb-5">
    <div class="container">
        <div class="row">
            <?php if($galle): ?>
                <?php  
                    // Decode the JSON string into an array of images
                    $images = json_decode($galle->image, true); 
                ?>

                <?php if(!empty($images) && is_array($images)): ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-4 col-sm-12 p-4">
                            <div class="galleryimg">
                                <!-- Display each image -->
                                <img src="<?php echo e(asset('public/images/gallery/' . trim($image))); ?>" alt="<?php echo e($galle->alt); ?>" style="width: 100%; height: auto;">

                               
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>No images available</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bandhavg/sevensafar.com/resources/views/front/gallery_image.blade.php ENDPATH**/ ?>