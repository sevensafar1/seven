 

<style>
    .addbtndes {
        background-color: #178750 !important;
        border: none !important;
        border-radius: 50% !important;
        padding: 7px 15px !important;  
    }
    .minusbtndes {
        background-color: #ee1010 !important;
        border: none !important;
        border-radius: 50% !important;
        padding: 9px 19px !important;
        margin-left: 11px;
    }
    .image-preview {
        width: 100px;
        height: 100px;
        object-fit: cover;
        margin: 5px;
    }
    .image-preview-container {
        display: flex;
        flex-wrap: wrap;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Gallery</h6>
                <form id="galleryForm" action="<?php echo e(route('gallery/update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="hidden" name="update_id" value="<?php echo e($gall->id); ?>">
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo e($gall->title); ?>">
                        <span class="text-danger" id="title_error"></span>
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" value="<?php echo e($gall->location); ?>">
                        <span class="text-danger" id="location_error"></span>
                    </div>
                    <div class="mb-3">
                        <label for="alt" class="form-label">Alt</label>
                        <input type="text" class="form-control" id="alt" name="alt" value="<?php echo e($gall->alt); ?>">
                        <span class="text-danger" id="alt_error"></span>
                    </div>

                    <div class="mb-3">
                        <label for="images" class="form-label">Images</label>
                        <input type="file" class="form-control" id="images" name="images">
                        <span class="text-danger" id="images_error"></span>
                    </div>

                    <!-- Show uploaded image if it exists -->
                    <?php if($gall->image): ?>
                    <div class="mb-3" id="uploadedImageContainer">
                        <img id="uploadedImage" src="<?php echo e(asset('images/gallery/' . $gall->image)); ?>" alt="Uploaded Image" style="max-width: 100%; height: auto;">
                    </div>
                    <?php endif; ?>

                    <!-- Image Preview for new upload -->
                    <div class="mb-3">
                        <img id="imagePreview" src="#" alt="Image Preview" style="display:none; max-width: 100%; height: auto;">
                    </div>

                    <button type="submit" class="btn btn-primary" id="submitBtn">
                        Submit
                        <span id="submitBtnSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Handle image preview
    document.getElementById('images').addEventListener('change', function(event) {
        var imagePreview = document.getElementById('imagePreview');
        var uploadedImageContainer = document.getElementById('uploadedImageContainer');

        var files = event.target.files; // Get selected files

        if (files.length > 0) {
            let file = files[0]; // We only need the first file (single file upload)

            if (file.type.startsWith('image/')) { // Ensure the file is an image
                let reader = new FileReader();
                
                reader.onload = function(e) {
                    // Hide the uploaded image
                    if (uploadedImageContainer) {
                        uploadedImageContainer.style.display = 'none';
                    }

                    // Show the new image preview
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block'; // Make preview visible
                };

                reader.readAsDataURL(file); // Read the image file
            }
        } else {
            // If no file is selected, show the uploaded image again (if it exists)
            if (uploadedImageContainer) {
                uploadedImageContainer.style.display = 'block';
            }
            imagePreview.style.display = 'none'; // Hide the image preview
        }
    });

    // Handle form submission with AJAX
    $(document).on('submit', 'form#galleryForm', function(event) {
        event.preventDefault(); // Prevent default form submission
        $('#loading').css('display', ''); // Show loading indicator

        var form = $(this);
        var data = new FormData(form[0]); // Gather form data
        var url = form.attr("action"); // Get form action URL
        $('#submitBtn').prop('disabled', true); // Disable the button
        $('#submitBtnSpinner').removeClass('d-none'); // Show spinner

        $.ajax({
            type: form.attr('method'), // POST method from form
            url: url, // URL for submission
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            success: function(response) {
                $('#loading').css('display', 'none'); // Hide loading indicator
                if (response.success) {
                    toastr.success(response.message); // Show success message
                    window.setTimeout(function() {
                        window.location.href = "<?php echo e(route('gallery/list')); ?>"; 
                    }, 1000);
                }
                $('#submitBtn').prop('disabled', false); // Re-enable the button
                $('#submitBtnSpinner').addClass('d-none'); // Hide spinner
            },
            error: function(err) {
                $('#loading').css('display', 'none'); // Hide loading indicator
                setTimeout(function() {
                    $('#submitBtn').prop('disabled', false); // Re-enable the button
                    $('#submitBtnSpinner').addClass('d-none'); // Hide spinner
                }, 3000); // 3 seconds delay

                if (err.status === 422) { // Handle validation errors
                    var error = $.parseJSON(err.responseText);
                    $.each(error.errors, function(key, val) {
                        $("#" + key + "_error").text(val); // Display validation errors
                    });
                }
            }
        });

        return false; // Prevent further event handling
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/admin/gallery/edit.blade.php ENDPATH**/ ?>