 


<style>
    .addbtndes
    {
        background-color: #178750 !important;
        border: none !important;
        border-radius: 50% !important;
        padding: 7px 15px !important;  
    }
    .minusbtndes
    {
        background-color: #ee1010 !important;
        border: none !important;
        border-radius: 50% !important;
        padding: 9px 19px !important;
        margin-left: 11px;
    }
</style>


<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Gallery</h6>
                <form id="galleryForm" action="<?php echo e(route('gallery/save')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title">
                        <span class="text-danger" id="title_error"></span>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Slug</label>
                        <input type="text" class="form-control" id="slug" name="slug">
                        <span class="text-danger" id="slug_error"></span>
                    </div>
                    
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location">
                        <span class="text-danger" id="location_error"></span>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Alt</label>
                        <input type="text" class="form-control" id="alt" name="alt">
                        <span class="text-danger" id="alt_error"></span>
                    </div>

                    <div class="mb-3">
                        <label for="images" class="form-label">Images</label>
                        <input type="file" class="form-control" id="images" name="images" multiple >
                        <span class="text-danger" id="images_error"></span>
                    </div>

                    <button type="submit" class="btn btn-primary" id="submitBtn">Submit
                    <span id="submitBtnSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                    
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).on('submit', 'form#galleryForm', function(event) {
        event.preventDefault(); // Prevent default form submission
        $('#loading').css('display', ''); // Show loading indicator (you can remove this line if not using loading indicator)
        
        var form = $(this);
        var data = new FormData(form[0]); // Gather form data
        var url = form.attr("action"); // Get form action URL
        $('#submitBtn').prop('disabled', true); // Disable the button
        $('#submitBtnSpinner').removeClass('d-none'); // Show spinner
        
        $.ajax({
            type: form.attr('method'), // POST method from form
            url: url, // URL for submission (must be specified in form's action attribute)
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            success: function(response) {
                $('#loading').css('display', 'none'); // Hide loading indicator
                if (response.success) {
                    toastr.success(response.message ); // Show success message (using Toastr for notifications)
                    window.setTimeout(function() {
                        window.location.href = "<?php echo e(route('dashboard')); ?>"; 
                    },1000);
                }
                    $('#submitBtn').prop('disabled', false); // Re-enable the button
                    $('#submitBtnSpinner').addClass('d-none'); // Hide spinner
            },
            error: function(err) {
                $('#loading').css('display', 'none'); // Hide loading indicator
                setTimeout(function() {
                            $('#submitBtn').prop('disabled', false); // Re-enable the button
                            $('#submitBtnSpinner').addClass('d-none'); // Hide spinner
                        }, 3000); // 3 seconds delay
                if (err.status === 422) { // Handle validation errors
                    $('#loading').css('display', 'none');
                    var error = $.parseJSON(err.responseText);
                    $.each(error.errors, function(key, val) {
                        $("#" + key + "_error").text(val); // Display validation errors next to inputs
                    });
                }
                
            }
        });

        return false; // Prevent further event handling
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevensafar\resources\views/admin/gallery/create.blade.php ENDPATH**/ ?>