@extends('layouts.admin.app') 
@section('content')
    <!-- Your custom content for index page goes here -->
    <div class="container">
        <h1>Welcome to the Admin Dashboard</h1>
        <!-- Other content for the page -->
    </div>
@endsection